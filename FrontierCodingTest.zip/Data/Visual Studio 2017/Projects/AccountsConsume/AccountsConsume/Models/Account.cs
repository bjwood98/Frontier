﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace AccountsConsume.Models
{
   public class Account
   {

      public enum AccountStatuses
      {
         Active,
         Inactive,
         Overdue
      }

      //public properties
      //TODO possible additional properties need to handle null values
      //TODO add error handling
      public int Id { get; set; }
      public string FirstName { get; set; }
      public string LastName { get; set; }
      public string Email { get; set; }
      public string PhoneNumber { get; set; }
      public decimal AmountDue { get; set; }
      public DateTime? PaymentDueDate { get; set; }
      public AccountStatuses AccountStatusId { get; set; }

      //readonly display properties
      public string NameDisplay
      {
         get
         {
            return LastName + ", " + FirstName;
         }
      }

      public string PhoneNumberDisplay
      {
         get
         {
            //possible extensions
            //there may be a better way to do this
            return Regex.Replace(PhoneNumber, @"(\d{3})(\d{3})(\d{4})", "($1)-$2-$3");
         }
      }

      public string AmountDueDisplay
      {
         get
         {
            return String.Format("{0:C}", AmountDue);
         }
      }

      public string DueDateDisplay
      {
         get
         {
            //update needed to hanle different locals
            return String.Format("{0:M/d/yyyy}", PaymentDueDate);
         }
      }

   }
}
