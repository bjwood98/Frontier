﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AccountsConsume.Models;
using System.Net.Http;
using Newtonsoft.Json;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AccountsConsume.Controllers
{
   public class HomeController : Controller
   {
      // GET: /<controller>/
      // TODO: Add more robust error handling
      public async Task<IActionResult> Index()
      {
         List<Account> accountList = new List<Account>();

         try
         {
            using (var httpClient = new HttpClient())
            {
               using (var response = await httpClient.GetAsync("https://frontiercodingtests.azurewebsites.net/api/accounts/getall"))
               {
                  string apiResponse = await response.Content.ReadAsStringAsync();
                  accountList = JsonConvert.DeserializeObject<List<Account>>(apiResponse);
               }
            }
         }
         catch (Exception)
         {
         }

         return View(accountList);
      }
   }
}
